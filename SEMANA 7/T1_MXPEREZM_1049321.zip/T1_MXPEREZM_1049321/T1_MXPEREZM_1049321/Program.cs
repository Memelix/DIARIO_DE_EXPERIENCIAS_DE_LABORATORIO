﻿using System;

namespace T1_MXPEREZM_1049321
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");

            /*COMENTARIO AQUI EMPIEZO A ESCRIBIR LOS DATOS*/
            Console.WriteLine("Escriba su nombre ");
            String Nombre = Console.ReadLine();
            Console.WriteLine("Escriba su Edad ");
            String Edad = Console.ReadLine();
            Console.WriteLine("Escriba su carrera ");
            String Carrera = Console.ReadLine();
            Console.WriteLine("Escriba su carnet");
            String Carnet = Console.ReadLine();
            Console.ReadKey();

            Console.WriteLine("Hola soy " + Nombre + " tengo " + Edad + " años y estudio la carrera de " + Carrera + " Mi número de carnet es " + Carnet);
            Console.ReadKey();
        }
    }
}