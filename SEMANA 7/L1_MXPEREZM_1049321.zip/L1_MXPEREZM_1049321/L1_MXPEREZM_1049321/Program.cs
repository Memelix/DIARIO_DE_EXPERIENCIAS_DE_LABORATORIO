﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_MXPEREZM_1049321
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre: ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy " + Nombre);

            /*COMENTARIOS*/

            Console.Write("Hola Mundo ");
            Console.Write("soy " + Nombre);
            Console.ReadKey();
        }
    }
}
